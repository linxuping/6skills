module.exports = {
    'ACCESS_KEY': '-YQ_Z6KbcOw1oGbhSM9au01otcr8UWvK5O4FfyiK',
    'SECRET_KEY': 'wDhQo8wTEuESIN2dMYd5pEBl_Yoe5RsX0x4dThxa',
    'Bucket_Name': 'sixskills',
    'Port': 19110,
    'Uptoken_Url': 'http://upload.qiniu.com',
    'Domain': 'http://sixskills.qunuicdn.com'
}
